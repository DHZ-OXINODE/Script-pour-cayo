Voici quelques lignes qui servent a afficher cayo perico sur votre serveur après nous avoir demander l'installation en ticket 

https://cdn.discordapp.com/attachments/802694471409467403/802701452598050846/test1.png

Notre site : https://oxinode.com/
Discord : https://discord.gg/4WxTtrh2gk
Espace Client : https://my.oxinode.com/
Panel de jeux :  https://game.oxinode.com/
Twitter : https://twitter.com/OxinodeFR
Twitch : https://www.twitch.tv/oxinodefr
Facebook : https://www.facebook.com/OxinodeFR